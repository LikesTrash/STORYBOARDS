# OSU-Storyboard-Engine
Python based Storyboard Engine by [Yumeno Himiko](https://osu.ppy.sh/u/1806962), [yf_bmp](https://osu.ppy.sh/u/1243669) and [[Mahua]](https://osu.ppy.sh/u/568761).

still work in progress

Visit [our wiki](https://github.com/frankhjwx/OSU-Storyboard-Engine/wiki) to learn how to use our tool.
