# python-osu-parser
A Python-library to parse .osu-files

This library is a translation from the Repo [nojhamster/osu-parser](https://github.com/nojhamster/osu-parser) and is supposed to work in the same manner
