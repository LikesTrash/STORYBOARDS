from Storyboard.StoryboardManager import *
import random
import math

# math.pi also works
pi = 3.1415926
song_folder = 'C:\\Users\\David Jiang\\AppData\\Local\\osu!\\Songs\\968733 Yura_Hatsuki - Sweet Halloween'
sb_filename = 'Yura_Hatsuki - Sweet Halloween (W8TERM3LON).osb'

#MUSIC INFO
def musicInfo():
    objs = []
    Pink = [236, 197, 183]
    pinkBar1 = Object('STBD/CDBG.png', origin='TopCentre', x=320, y=0)
    pinkBar1.Vector(0, '01:56:673', 854, 100)
    pinkBar1.Color(0, Pink)

    objs.append(pinkBar1)

    return Scene(objs)

# Create StoryboardManager
SBManager = StoryboardManager(song_folder, sb_filename, create_backup=True)

#To alias Variables
musin = musicInfo()

SBManager.generate_storyboard(diff_specific=True)
SBManager.delete_backups()